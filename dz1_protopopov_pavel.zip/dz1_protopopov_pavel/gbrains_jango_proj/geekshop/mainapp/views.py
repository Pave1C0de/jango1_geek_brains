from django.shortcuts import render
def index(request):
    return render(request, 'mainapp/index.html')
# Create your views here.

def products(request):
    return render(request, 'mainapp/products.html')

def contact(request):
    return render(request, 'mainapp/contact.html')
